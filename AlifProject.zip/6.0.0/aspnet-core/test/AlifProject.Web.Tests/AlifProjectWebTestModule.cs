﻿using Abp.AspNetCore;
using Abp.AspNetCore.TestBase;
using Abp.Modules;
using Abp.Reflection.Extensions;
using AlifProject.EntityFrameworkCore;
using AlifProject.Web.Startup;
using Microsoft.AspNetCore.Mvc.ApplicationParts;

namespace AlifProject.Web.Tests
{
    [DependsOn(
        typeof(AlifProjectWebMvcModule),
        typeof(AbpAspNetCoreTestBaseModule)
    )]
    public class AlifProjectWebTestModule : AbpModule
    {
        public AlifProjectWebTestModule(AlifProjectEntityFrameworkModule abpProjectNameEntityFrameworkModule)
        {
            abpProjectNameEntityFrameworkModule.SkipDbContextRegistration = true;
        } 
        
        public override void PreInitialize()
        {
            Configuration.UnitOfWork.IsTransactional = false; //EF Core InMemory DB does not support transactions.
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(AlifProjectWebTestModule).GetAssembly());
        }
        
        public override void PostInitialize()
        {
            IocManager.Resolve<ApplicationPartManager>()
                .AddApplicationPartsIfNotAddedBefore(typeof(AlifProjectWebMvcModule).Assembly);
        }
    }
}