﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using AlifProject.Authorization.Roles;
using AlifProject.Authorization.Users;
using AlifProject.MultiTenancy;

namespace AlifProject.EntityFrameworkCore
{
    public class AlifProjectDbContext : AbpZeroDbContext<Tenant, Role, User, AlifProjectDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public AlifProjectDbContext(DbContextOptions<AlifProjectDbContext> options)
            : base(options)
        {
        }
    }
}
