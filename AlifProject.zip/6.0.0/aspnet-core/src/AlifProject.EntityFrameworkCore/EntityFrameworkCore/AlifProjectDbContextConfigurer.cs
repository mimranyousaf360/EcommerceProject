using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace AlifProject.EntityFrameworkCore
{
    public static class AlifProjectDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<AlifProjectDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<AlifProjectDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
