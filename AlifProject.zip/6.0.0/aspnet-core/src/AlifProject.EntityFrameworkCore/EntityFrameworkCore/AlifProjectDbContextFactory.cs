﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using AlifProject.Configuration;
using AlifProject.Web;

namespace AlifProject.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class AlifProjectDbContextFactory : IDesignTimeDbContextFactory<AlifProjectDbContext>
    {
        public AlifProjectDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<AlifProjectDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            AlifProjectDbContextConfigurer.Configure(builder, configuration.GetConnectionString(AlifProjectConsts.ConnectionStringName));

            return new AlifProjectDbContext(builder.Options);
        }
    }
}
