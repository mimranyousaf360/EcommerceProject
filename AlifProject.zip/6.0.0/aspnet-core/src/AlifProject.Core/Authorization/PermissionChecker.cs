﻿using Abp.Authorization;
using AlifProject.Authorization.Roles;
using AlifProject.Authorization.Users;

namespace AlifProject.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}
