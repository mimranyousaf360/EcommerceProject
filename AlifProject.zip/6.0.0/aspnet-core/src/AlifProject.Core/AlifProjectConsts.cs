﻿namespace AlifProject
{
    public class AlifProjectConsts
    {
        public const string LocalizationSourceName = "AlifProject";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
