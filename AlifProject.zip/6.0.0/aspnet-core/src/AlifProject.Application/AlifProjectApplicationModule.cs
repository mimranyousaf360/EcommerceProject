﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using AlifProject.Authorization;

namespace AlifProject
{
    [DependsOn(
        typeof(AlifProjectCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class AlifProjectApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<AlifProjectAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(AlifProjectApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }
    }
}
