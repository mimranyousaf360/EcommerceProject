﻿using Abp.Application.Services;
using AlifProject.MultiTenancy.Dto;

namespace AlifProject.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedTenantResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

