﻿using System.Threading.Tasks;
using AlifProject.Configuration.Dto;

namespace AlifProject.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
