using System.ComponentModel.DataAnnotations;

namespace AlifProject.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}