﻿using Microsoft.AspNetCore.Mvc;
using Abp.AspNetCore.Mvc.Authorization;
using AlifProject.Controllers;

namespace AlifProject.Web.Controllers
{
    [AbpMvcAuthorize]
    public class HomeController : AlifProjectControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
