﻿using Abp.AspNetCore.Mvc.ViewComponents;

namespace AlifProject.Web.Views
{
    public abstract class AlifProjectViewComponent : AbpViewComponent
    {
        protected AlifProjectViewComponent()
        {
            LocalizationSourceName = AlifProjectConsts.LocalizationSourceName;
        }
    }
}
