﻿using Abp.Application.Navigation;

namespace AlifProject.Web.Views.Shared.Components.SideBarMenu
{
    public class SideBarMenuViewModel
    {
        public UserMenu MainMenu { get; set; }
    }
}
