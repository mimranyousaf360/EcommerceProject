﻿using System.Collections.Generic;
using AlifProject.Roles.Dto;

namespace AlifProject.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}
