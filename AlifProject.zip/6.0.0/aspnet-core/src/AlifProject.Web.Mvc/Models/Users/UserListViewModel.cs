using System.Collections.Generic;
using AlifProject.Roles.Dto;

namespace AlifProject.Web.Models.Users
{
    public class UserListViewModel
    {
        public IReadOnlyList<RoleDto> Roles { get; set; }
    }
}
